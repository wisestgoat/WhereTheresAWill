(Thanks for reporting an issue! Please make sure to fill out the blanks below.)

What's wrong, and with what software version?
---------------------------------------------
**Operating System:** …  
**CEmu version:** … (see in the `About CEmu` menu)  
**Describe your issue:**  
… (including, if applicable what you expect vs. what happens)  

What are the steps to reproduce this issue?
-------------------------------------------
1. …
2. …
3. …

Any logs, error output, screenshot, other comments...?
------------------------------------------------------
…
